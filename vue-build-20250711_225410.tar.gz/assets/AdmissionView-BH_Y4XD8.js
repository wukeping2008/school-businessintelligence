import{j as Q,r as x,a as M,d as j,k as r,l as e,p as t,J as k,K as O,L as _,M as y,x as S,N as U,O as m,A as c,u as V,P as q}from"./element-plus-DedIufIX.js";import{u as B}from"./index-tWW-F9bR.js";import{_ as T}from"./_plugin-vue_export-helper-DlAUqK2U.js";const W={class:"page active"},F={class:"page-header"},G={class:"admission-container"},H={key:0,class:"questionnaire-section"},K={class:"progress-bar"},J={class:"progress-text"},X={class:"question-container"},Y={key:0,class:"question"},Z={key:0,class:"question-options"},ee=["onClick"],te=["name","value"],se={key:1},ne=["placeholder"],ie={class:"navigation-buttons"},oe=["disabled"],ae=["disabled"],le={key:1,class:"report-section"},re={class:"report-header"},ce={class:"student-info"},de={class:"report-content"},ue={class:"report-card"},pe={class:"recommendations"},me={class:"report-card"},ve={class:"timeline-planning"},he={class:"timeline-date"},ge={class:"timeline-content"},_e={class:"report-card"},ye={class:"expectations"},be={class:"report-card"},ke={class:"milestones"},fe={class:"milestone-date"},$e={class:"milestone-task"},xe={class:"report-actions"},je=Q({__name:"AdmissionView",setup(Se){const p=B(),d=l=>p.t(l),n=x(0),i=M({}),b=x(!1),v=x([{type:"text"},{type:"multiple"},{type:"multiple"},{type:"multiple"},{type:"multiple"}]),f=j(()=>v.value[n.value]),C=j(()=>(n.value+1)/v.value.length*100),L=l=>({zh:["请输入学生姓名","学生目前的年级是？","学生最感兴趣的学科领域是？","学生的学习目标是什么？","希望重点关注哪个方面的发展？"],en:["Please enter student name","What is the student's current grade level?","What subject area is the student most interested in?","What are the student's learning goals?","Which aspect of development would you like to focus on?"]})[p.currentLanguage][l]||"",A=l=>({zh:["我们将为您生成个性化的学业规划报告","了解学生当前的学习阶段","帮助我们了解学生的兴趣方向","明确学习目标有助于制定合适的规划","我们将根据您的选择提供针对性建议"],en:["We will generate a personalized academic planning report for you","Understanding the student's current learning stage","Help us understand the student's interests","Clear learning goals help develop appropriate plans","We will provide targeted suggestions based on your choices"]})[p.currentLanguage][l]||"",E=l=>({zh:[[],["小学1-3年级","小学4-6年级","初中7-9年级","高中10-12年级"],["数学与科学","语言文学","艺术创作","体育运动","社会科学"],["提高学术成绩","培养特长技能","准备升学考试","全面发展","兴趣探索"],["学术能力提升","创新思维培养","领导力发展","国际视野拓展","实践能力锻炼"]],en:[[],["Elementary 1-3","Elementary 4-6","Middle School 7-9","High School 10-12"],["Math & Science","Language & Literature","Arts & Creativity","Sports & Athletics","Social Sciences"],["Improve Academic Performance","Develop Special Skills","Prepare for Entrance Exams","Comprehensive Development","Interest Exploration"],["Academic Ability Enhancement","Creative Thinking Development","Leadership Development","International Perspective","Practical Skills Training"]]})[p.currentLanguage][l]||[],w=l=>({zh:["请输入学生姓名","","","",""],en:["Please enter student name","","","",""]})[p.currentLanguage][l]||"",h=()=>({zh:{courses:[{subject:"数学强化",description:"基于学生兴趣，建议加强数学逻辑思维训练"},{subject:"科学探索",description:"培养实验能力和科学思维方法"},{subject:"语言表达",description:"提升中英文表达和沟通能力"}],timeline:[{period:"第1学期",activity:"基础能力评估与强化训练"},{period:"第2学期",activity:"专项技能培养与实践应用"},{period:"第3学期",activity:"综合能力提升与成果展示"}],expectations:["学术成绩稳步提升，各科目均衡发展","培养独立思考和解决问题的能力","建立良好的学习习惯和时间管理能力"],milestones:[{date:"3个月后",task:"完成基础能力评估"},{date:"6个月后",task:"达成第一阶段学习目标"},{date:"1年后",task:"实现综合能力显著提升"}]},en:{courses:[{subject:"Math Enhancement",description:"Based on student interests, recommend strengthening mathematical logical thinking training"},{subject:"Science Exploration",description:"Develop experimental skills and scientific thinking methods"},{subject:"Language Expression",description:"Improve Chinese and English expression and communication skills"}],timeline:[{period:"Semester 1",activity:"Basic ability assessment and strengthening training"},{period:"Semester 2",activity:"Specialized skill development and practical application"},{period:"Semester 3",activity:"Comprehensive ability improvement and achievement demonstration"}],expectations:["Steady improvement in academic performance with balanced development across subjects","Develop independent thinking and problem-solving abilities","Establish good study habits and time management skills"],milestones:[{date:"After 3 months",task:"Complete basic ability assessment"},{date:"After 6 months",task:"Achieve first-stage learning goals"},{date:"After 1 year",task:"Achieve significant improvement in comprehensive abilities"}]}})[p.currentLanguage],P=l=>{i[n.value]=l},R=()=>{n.value>0&&n.value--},D=()=>{n.value<v.value.length-1?n.value++:z()},z=()=>{b.value=!0},N=()=>{n.value=0,Object.keys(i).forEach(l=>delete i[parseInt(l)]),b.value=!1},I=()=>{const l=p.currentLanguage==="en",s=h(),a=l?`
Academic Planning Report
Student Name: ${i[0]||"Student"}
Grade Level: ${i[1]||"Not specified"}
Interest Area: ${i[2]||"Not specified"}
Learning Goals: ${i[3]||"Not specified"}
Development Focus: ${i[4]||"Not specified"}

Course Recommendations:
${s.courses.map(o=>`- ${o.subject}: ${o.description}`).join(`
`)}

Timeline Planning:
${s.timeline.map(o=>`- ${o.period}: ${o.activity}`).join(`
`)}

Expected Outcomes:
${s.expectations.map(o=>`- ${o}`).join(`
`)}

Key Milestones:
${s.milestones.map(o=>`- ${o.date}: ${o.task}`).join(`
`)}
  `:`
学业规划报告
学生姓名: ${i[0]||"学生"}
年级: ${i[1]||"未填写"}
兴趣领域: ${i[2]||"未填写"}
学习目标: ${i[3]||"未填写"}
发展重点: ${i[4]||"未填写"}

课程推荐:
${s.courses.map(o=>`- ${o.subject}: ${o.description}`).join(`
`)}

时间规划:
${s.timeline.map(o=>`- ${o.period}: ${o.activity}`).join(`
`)}

预期目标:
${s.expectations.map(o=>`- ${o}`).join(`
`)}

关键里程碑:
${s.milestones.map(o=>`- ${o.date}: ${o.task}`).join(`
`)}
  `,u=new Blob([a],{type:"text/plain;charset=utf-8"}),g=URL.createObjectURL(u),$=document.createElement("a");$.href=g,$.download=l?`Academic_Planning_Report_${i[0]||"Student"}.txt`:`学业规划报告_${i[0]||"学生"}.txt`,$.click(),URL.revokeObjectURL(g)};return(l,s)=>(c(),r("div",W,[e("div",F,[e("h1",null,t(d("admission.title")),1),e("p",null,t(d("admission.subtitle")),1)]),e("div",G,[b.value?k("",!0):(c(),r("div",H,[e("div",K,[e("div",{class:"progress-fill",style:O({width:C.value+"%"})},null,4),e("span",J,t(d("admission.progress.step"))+" "+t(n.value+1)+"/"+t(v.value.length),1)]),e("div",X,[f.value?(c(),r("div",Y,[e("h3",null,t(L(n.value)),1),e("p",null,t(A(n.value)),1),f.value.type==="multiple"?(c(),r("div",Z,[(c(!0),r(_,null,y(E(n.value),(a,u)=>(c(),r("div",{key:u,class:V(["option",{selected:i[n.value]===a}]),onClick:g=>P(a)},[S(e("input",{type:"radio",name:`question-${n.value}`,value:a,"onUpdate:modelValue":s[0]||(s[0]=g=>i[n.value]=g)},null,8,te),[[q,i[n.value]]]),m(" "+t(a),1)],10,ee))),128))])):f.value.type==="text"?(c(),r("div",se,[S(e("input",{type:"text",class:"text-input","onUpdate:modelValue":s[1]||(s[1]=a=>i[n.value]=a),placeholder:w(n.value)},null,8,ne),[[U,i[n.value]]])])):k("",!0)])):k("",!0)]),e("div",ie,[e("button",{class:"btn btn-secondary",onClick:R,disabled:n.value===0},t(d("common.previous")),9,oe),e("button",{class:"btn btn-primary",onClick:D,disabled:!i[n.value]},t(n.value===v.value.length-1?d("admission.generate"):d("common.next")),9,ae)])])),b.value?(c(),r("div",le,[e("div",re,[e("h2",null,t(d("admission.report.title")),1),e("div",ce,t(d("admission.report.student"))+": "+t(i[0]||d("common.student")),1)]),e("div",de,[e("div",ue,[e("h3",null,[s[2]||(s[2]=e("i",{class:"fas fa-book"},null,-1)),m(" "+t(d("admission.report.recommendations")),1)]),e("div",pe,[(c(!0),r(_,null,y(h().courses,(a,u)=>(c(),r("div",{key:u,class:"recommendation-item"},[e("strong",null,t(a.subject),1),m(": "+t(a.description),1)]))),128))])]),e("div",me,[e("h3",null,[s[3]||(s[3]=e("i",{class:"fas fa-calendar-alt"},null,-1)),m(" "+t(d("admission.report.timeline")),1)]),e("div",ve,[(c(!0),r(_,null,y(h().timeline,(a,u)=>(c(),r("div",{key:u,class:"timeline-item"},[e("div",he,t(a.period),1),e("div",ge,t(a.activity),1)]))),128))])]),e("div",_e,[e("h3",null,[s[4]||(s[4]=e("i",{class:"fas fa-bullseye"},null,-1)),m(" "+t(d("admission.report.expectations")),1)]),e("div",ye,[(c(!0),r(_,null,y(h().expectations,(a,u)=>(c(),r("div",{key:u,class:"expectation-item"},t(a),1))),128))])]),e("div",be,[e("h3",null,[s[5]||(s[5]=e("i",{class:"fas fa-tasks"},null,-1)),m(" "+t(d("admission.report.milestones")),1)]),e("div",ke,[(c(!0),r(_,null,y(h().milestones,(a,u)=>(c(),r("div",{key:u,class:"milestone-item"},[e("div",fe,t(a.date),1),e("div",$e,t(a.task),1)]))),128))])])]),e("div",xe,[e("button",{class:"btn btn-secondary",onClick:N},t(d("admission.restart")),1),e("button",{class:"btn btn-primary",onClick:I},t(d("admission.download")),1)])])):k("",!0)])]))}}),Ee=T(je,[["__scopeId","data-v-f0fdf544"]]);export{Ee as default};
